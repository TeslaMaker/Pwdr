modified from boreaz firmware
